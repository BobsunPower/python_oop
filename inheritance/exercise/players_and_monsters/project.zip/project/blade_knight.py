# from inheritance.exercise.players_and_monsters.project.dark_knight import DarkKnight
from project.dark_knight import DarkKnight


class BladeKnight(DarkKnight):
    pass
