# from inheritance.exercise.players_and_monsters.project.hero import Hero
from project.hero import Hero


class Elf(Hero):
    pass
