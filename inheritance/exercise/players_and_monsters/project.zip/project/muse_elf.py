# from inheritance.exercise.players_and_monsters.project.elf import Elf
from project.elf import Elf


class MuseElf(Elf):
    pass
