# from inheritance.exercise.players_and_monsters.project.knight import Knight
from project.knight import Knight


class DarkKnight(Knight):
    pass
