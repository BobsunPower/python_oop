# from inheritance.exercise.players_and_monsters.project.wizard import Wizard
from project.wizard import Wizard


class DarkWizard(Wizard):
    pass
